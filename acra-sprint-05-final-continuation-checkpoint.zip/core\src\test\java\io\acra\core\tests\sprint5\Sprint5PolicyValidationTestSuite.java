package io.acra.core.tests.sprint5;

import io.acra.core.active.evidence.EvidenceReferenceValidator;
import io.acra.core.active.evidence.EvidenceStage;
import io.acra.core.active.evidence.ExecutionEvidenceStore;
import io.acra.core.domain.authorization.Action;
import io.acra.core.domain.authorization.ActionType;
import io.acra.core.domain.authorization.AuthorizationContext;
import io.acra.core.domain.authorization.AuthorizationDecision;
import io.acra.core.domain.authorization.ContextStatus;
import io.acra.core.domain.authorization.PolicyValidationResult;
import io.acra.core.domain.authorization.PolicyValidationState;
import io.acra.core.domain.common.Confidence;
import io.acra.core.domain.evidence.EvidenceSource;
import io.acra.core.domain.identity.AuthenticationType;
import io.acra.core.domain.identity.Principal;
import io.acra.core.domain.identity.Role;
import io.acra.core.domain.resource.Resource;
import io.acra.core.domain.tenant.Tenant;
import io.acra.core.domain.workflow.WorkflowState;
import io.acra.core.engine.PolicyValidationEvaluator;
import io.acra.core.serialization.DomainSerializer;
import io.acra.core.tests.TestSupport;

import java.util.ArrayList;
import java.util.List;

public final class Sprint5PolicyValidationTestSuite {
	private Sprint5PolicyValidationTestSuite() { }

	public static void main(String[] args) {
		int assertions = run();
		System.out.println("SPRINT5_POLICY_VALIDATION PASS assertions=" + assertions);
	}

	public static int run() {
		int assertions = 0;
		ExecutionEvidenceStore store = new ExecutionEvidenceStore("project-a");
		store.append("execution-1", "test-1", EvidenceStage.TEST, "evidence-1", "tenant-policy");
		store.append("execution-1", "test-1", EvidenceStage.TEST, "evidence-2", "workflow-policy");
		store.append("execution-1", "test-1", EvidenceStage.TEST, "evidence-3", "property-policy");
		PolicyValidationEvaluator evaluator = new PolicyValidationEvaluator(new EvidenceReferenceValidator(store));

		assertions += tenantReviews(evaluator);
		assertions += workflowReviews(evaluator);
		assertions += propertyReviews(evaluator);
		assertions += conflictReviews(evaluator);
		assertions += forgedObservationIsRejected(evaluator);
		assertions += securityAndImmutability(evaluator);
		return assertions;
	}

	private static int forgedObservationIsRejected(PolicyValidationEvaluator evaluator) {
		AuthorizationContext context = context("tenant-a", "tenant-a", "viewer", AuthorizationDecision.ALLOW,
				AuthorizationDecision.ALLOW, ContextStatus.RESOLVED);
		var policy = new PolicyValidationEvaluator.TenantPolicy("tenant-policy", "supplied-tenant-rule",
				"tenant-a", "tenant-a", "viewer", false, false, AuthorizationDecision.ALLOW, List.of("evidence-1"));
		PolicyValidationResult result = evaluator.reviewTenant(context, policy, "forged-observation",
				"execution-1", "test-1", "project-a");
		TestSupport.assertEquals(PolicyValidationState.INCONCLUSIVE, result.state(),
				"unresolved observation reference cannot create supported policy result");
		return 1;
	}

	private static int tenantReviews(PolicyValidationEvaluator evaluator) {
		int assertions = 0;
		AuthorizationContext sameTenant = context("tenant-a", "tenant-a", "viewer", AuthorizationDecision.ALLOW,
				AuthorizationDecision.ALLOW, ContextStatus.RESOLVED);
		var samePolicy = new PolicyValidationEvaluator.TenantPolicy("tenant-policy", "supplied-tenant-rule",
				"tenant-a", "tenant-a", "viewer", false, false, AuthorizationDecision.ALLOW, List.of("evidence-1"));
		assertions += state(PolicyValidationState.ALLOWED, evaluator.reviewTenant(sameTenant, samePolicy,
				"observation-1", "execution-1", "test-1", "project-a"), "same tenant allow");

		AuthorizationContext crossTenant = context("tenant-a", "tenant-b", "viewer", AuthorizationDecision.DENY,
				AuthorizationDecision.DENY, ContextStatus.RESOLVED);
		var crossPolicy = new PolicyValidationEvaluator.TenantPolicy("tenant-policy-cross", "supplied-tenant-rule",
				"tenant-a", "tenant-b", "viewer", false, false, AuthorizationDecision.DENY, List.of("evidence-1"));
		assertions += state(PolicyValidationState.DENIED, evaluator.reviewTenant(crossTenant, crossPolicy,
				"observation-1", "execution-1", "test-1", "project-a"), "cross tenant deny");

		AuthorizationContext admin = context("tenant-a", "tenant-b", "global-admin", AuthorizationDecision.ALLOW,
				AuthorizationDecision.ALLOW, ContextStatus.RESOLVED);
		var adminPolicy = new PolicyValidationEvaluator.TenantPolicy("tenant-policy-admin", "supplied-tenant-rule",
				"tenant-a", "tenant-b", "global-admin", true, false, AuthorizationDecision.ALLOW, List.of("evidence-1"));
		assertions += state(PolicyValidationState.ALLOWED, evaluator.reviewTenant(admin, adminPolicy,
				"observation-1", "execution-1", "test-1", "project-a"), "explicit global administrator allow");

		var delegatedPolicy = new PolicyValidationEvaluator.TenantPolicy("tenant-policy-delegated", "supplied-tenant-rule",
				"tenant-a", "tenant-b", "delegated", false, true, AuthorizationDecision.ALLOW, List.of("evidence-1"));
		assertions += state(PolicyValidationState.ALLOWED, evaluator.reviewTenant(
				context("tenant-a", "tenant-b", "delegated", AuthorizationDecision.ALLOW, AuthorizationDecision.ALLOW,
						ContextStatus.RESOLVED), delegatedPolicy, "observation-1", "execution-1", "test-1", "project-a"),
				"explicit delegated tenant privilege");

		assertions += state(PolicyValidationState.INCONCLUSIVE, evaluator.reviewTenant(
				context(null, "tenant-b", "viewer", AuthorizationDecision.UNKNOWN, AuthorizationDecision.UNKNOWN,
						ContextStatus.PARTIAL), crossPolicy, "observation-1", "execution-1", "test-1", "project-a"),
				"missing tenant");
		assertions += state(PolicyValidationState.CONFLICTING, evaluator.reviewTenant(
				context("tenant-a", "tenant-a", "viewer", AuthorizationDecision.ALLOW, AuthorizationDecision.ALLOW,
						ContextStatus.CONFLICTING_EVIDENCE), samePolicy, "observation-1", "execution-1", "test-1", "project-a"),
				"conflicting tenant evidence");
		return assertions;
	}

	private static int workflowReviews(PolicyValidationEvaluator evaluator) {
		int assertions = 0;
		AuthorizationContext allowed = context("tenant-a", "tenant-a", "reviewer", AuthorizationDecision.ALLOW,
				AuthorizationDecision.ALLOW, ContextStatus.RESOLVED);
		var valid = new PolicyValidationEvaluator.WorkflowPolicy("workflow-policy", "supplied-workflow-rule",
				"DRAFT", "SUBMITTED", "reviewer", false, false, false, AuthorizationDecision.ALLOW,
				List.of("evidence-2"));
		assertions += state(PolicyValidationState.ALLOWED, evaluator.reviewWorkflow(allowed, valid, "DRAFT", "SUBMITTED",
				false, true, "observation-1", "execution-1", "test-1", "project-a"), "valid transition");

		var denied = new PolicyValidationEvaluator.WorkflowPolicy("workflow-deny", "supplied-workflow-rule",
				"DRAFT", "APPROVED", "reviewer", false, false, false, AuthorizationDecision.DENY,
				List.of("evidence-2"));
		assertions += state(PolicyValidationState.DENIED, evaluator.reviewWorkflow(
				context("tenant-a", "tenant-a", "viewer", AuthorizationDecision.DENY, AuthorizationDecision.DENY,
						ContextStatus.RESOLVED), denied, "DRAFT", "SUBMITTED", false, true,
				"observation-1", "execution-1", "test-1", "project-a"), "unauthorized transition");

		var terminal = new PolicyValidationEvaluator.WorkflowPolicy("workflow-terminal", "supplied-workflow-rule",
				"CLOSED", "REOPENED", "reviewer", false, false, true, AuthorizationDecision.DENY,
				List.of("evidence-2"));
		assertions += state(PolicyValidationState.DENIED, evaluator.reviewWorkflow(
				context("tenant-a", "tenant-a", "reviewer", AuthorizationDecision.DENY, AuthorizationDecision.DENY,
						ContextStatus.RESOLVED), terminal, "CLOSED", "REOPENED", false, true,
				"observation-1", "execution-1", "test-1", "project-a"), "terminal state restriction");

		assertions += state(PolicyValidationState.INCONCLUSIVE, evaluator.reviewWorkflow(allowed, valid, "UNKNOWN",
				"SUBMITTED", false, true, "observation-1", "execution-1", "test-1", "project-a"), "unknown workflow state");
		var missingEvidence = new PolicyValidationEvaluator.WorkflowPolicy("workflow-missing-evidence", "supplied-workflow-rule",
				"DRAFT", "SUBMITTED", "reviewer", true, false, false, AuthorizationDecision.ALLOW, List.of());
		assertions += state(PolicyValidationState.INCONCLUSIVE, evaluator.reviewWorkflow(allowed, missingEvidence,
				"DRAFT", "SUBMITTED", true, true, "observation-1", "execution-1", "test-1", "project-a"),
				"missing transition evidence");
		return assertions;
	}

	private static int propertyReviews(PolicyValidationEvaluator evaluator) {
		int assertions = 0;
		AuthorizationContext reader = context("tenant-a", "tenant-a", "reader", AuthorizationDecision.ALLOW,
				AuthorizationDecision.ALLOW, ContextStatus.RESOLVED);
		var allowed = new PolicyValidationEvaluator.PropertyPolicy("property-read", "supplied-property-rule",
				"GET /documents/{id}", "password", PolicyValidationEvaluator.PropertyOperation.READ,
				"reader", "tenant-a", AuthorizationDecision.ALLOW, List.of("evidence-3"));
		assertions += state(PolicyValidationState.ALLOWED, evaluator.reviewProperty(reader, allowed, "password",
				PolicyValidationEvaluator.PropertyOperation.READ, "GET /documents/{id}", "observation-1",
				"execution-1", "test-1", "project-a"), "explicit allowed field");

		var denied = new PolicyValidationEvaluator.PropertyPolicy("property-deny", "supplied-property-rule",
				"GET /documents/{id}", "role", PolicyValidationEvaluator.PropertyOperation.READ,
				"reader", "tenant-a", AuthorizationDecision.DENY, List.of("evidence-3"));
		assertions += state(PolicyValidationState.DENIED, evaluator.reviewProperty(
				context("tenant-a", "tenant-a", "reader", AuthorizationDecision.DENY, AuthorizationDecision.DENY,
						ContextStatus.RESOLVED), denied, "role", PolicyValidationEvaluator.PropertyOperation.READ,
				"GET /documents/{id}", "observation-1", "execution-1", "test-1", "project-a"), "denied field");

		assertions += state(PolicyValidationState.CONFLICTING, evaluator.reviewProperty(reader, denied, "role",
				PolicyValidationEvaluator.PropertyOperation.READ, "GET /documents/{id}", "observation-1",
				"execution-1", "test-1", "project-a"), "unauthorized disclosure conflict");
		var mutation = new PolicyValidationEvaluator.PropertyPolicy("property-update", "supplied-property-rule",
				"PATCH /documents/{id}", "owner", PolicyValidationEvaluator.PropertyOperation.UPDATE,
				"editor", "tenant-a", AuthorizationDecision.DENY, List.of("evidence-3"));
		assertions += state(PolicyValidationState.CONFLICTING, evaluator.reviewProperty(reader, mutation, "owner",
				PolicyValidationEvaluator.PropertyOperation.UPDATE, "PATCH /documents/{id}", "observation-1",
				"execution-1", "test-1", "project-a"), "unauthorized mutation conflict");
		assertions += state(PolicyValidationState.INCONCLUSIVE, evaluator.reviewProperty(reader, null, "unknown",
				PolicyValidationEvaluator.PropertyOperation.READ, "GET /documents/{id}", "observation-1",
				"execution-1", "test-1", "project-a"), "unknown property policy");
		return assertions;
	}

	private static int conflictReviews(PolicyValidationEvaluator evaluator) {
		AuthorizationContext allowContext = context("tenant-a", "tenant-a", "viewer", AuthorizationDecision.ALLOW,
				AuthorizationDecision.ALLOW, ContextStatus.RESOLVED);
		AuthorizationContext denyContext = context("tenant-a", "tenant-a", "viewer", AuthorizationDecision.DENY,
				AuthorizationDecision.DENY, ContextStatus.RESOLVED);
		var allow = new PolicyValidationEvaluator.TenantPolicy("allow-policy", "tenant-source", "tenant-a",
				"tenant-a", "viewer", false, false, AuthorizationDecision.ALLOW, List.of("evidence-1"));
		var deny = new PolicyValidationEvaluator.TenantPolicy("deny-policy", "resource-source", "tenant-a",
				"tenant-a", "viewer", false, false, AuthorizationDecision.DENY, List.of("evidence-1"));
		PolicyValidationResult allowed = evaluator.reviewTenant(allowContext, allow, "observation-1",
				"execution-1", "test-1", "project-a");
		PolicyValidationResult denied = evaluator.reviewTenant(denyContext, deny, "observation-1",
				"execution-1", "test-1", "project-a");
		PolicyValidationResult first = evaluator.reviewConflict(List.of(allowed, denied));
		PolicyValidationResult second = evaluator.reviewConflict(List.of(denied, allowed));
		TestSupport.assertEquals(PolicyValidationState.CONFLICTING, first.state(), "ALLOW/DENY remains conflicting");
		TestSupport.assertEquals(first, second, "conflict output is deterministic");
		TestSupport.assertTrue(first.rationale().contains("no precedence"), "conflict precedence is not inferred");
		return 3;
	}

	private static int securityAndImmutability(PolicyValidationEvaluator evaluator) {
		List<String> evidence = new ArrayList<>(List.of("evidence-1"));
		var policy = new PolicyValidationEvaluator.TenantPolicy("safe-policy", "password=DummyPassword",
				"tenant-a", "tenant-a", "viewer", false, false, AuthorizationDecision.ALLOW, evidence);
		evidence.clear();
		TestSupport.assertEquals(List.of("evidence-1"), policy.evidenceIds(), "policy evidence is immutable");
		AuthorizationContext context = context("tenant-a", "tenant-a", "viewer", AuthorizationDecision.ALLOW,
				AuthorizationDecision.ALLOW, ContextStatus.RESOLVED);
		PolicyValidationResult result = evaluator.reviewTenant(context, policy, "observation-1", "execution-1",
				"test-1", "project-a");
		String serialized = new DomainSerializer().serialize(result);
		for (String secret : List.of("DummyPassword", "DummyToken", "DummyApiKey", "DummyAuthorization", "DummyCookie", "DummySession")) {
			TestSupport.assertNotContains(serialized, secret, "policy review does not leak " + secret);
		}
		TestSupport.assertEquals("evidence-1", policy.evidenceIds().getFirst(), "historical evidence reference preserved");
		return 8;
	}

	private static AuthorizationContext context(String principalTenant, String resourceTenant, String role,
											   AuthorizationDecision expected, AuthorizationDecision observed,
											   ContextStatus status) {
		Principal principal = new Principal("user-a", "User A", AuthenticationType.UNKNOWN, Confidence.unknown());
		Role assignedRole = new Role(role == null ? "viewer" : role, role == null ? "viewer" : role,
				EvidenceSource.UNKNOWN, Confidence.unknown());
		Tenant tenant = principalTenant == null ? null : new Tenant(principalTenant, principalTenant,
				EvidenceSource.UNKNOWN, Confidence.unknown());
		Resource resource = new Resource("document-1", "document", null, "user-a", resourceTenant,
				"ACTIVE", Confidence.unknown());
		Action action = new Action(ActionType.READ, EvidenceSource.UNKNOWN, Confidence.unknown(), "READ");
		return new AuthorizationContext(principal, assignedRole, tenant, resource, "user-a", action,
				new WorkflowState("DRAFT", Confidence.unknown()), expected, observed, List.of("evidence-1"), status);
	}

	private static int state(PolicyValidationState expected, PolicyValidationResult actual, String message) {
		TestSupport.assertEquals(expected, actual.state(), message + " state");
		return 1;
	}
}
