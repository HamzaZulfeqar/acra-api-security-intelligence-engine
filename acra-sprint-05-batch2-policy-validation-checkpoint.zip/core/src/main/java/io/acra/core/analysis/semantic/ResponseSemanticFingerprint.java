package io.acra.core.analysis.semantic;
import java.util.*;
public record ResponseSemanticFingerprint(int status,String contentType,int bodyLength,SemanticResponseClass responseClass,
                                          Set<String> fields,Set<String> resourceIds,Set<String> ownerIds,Set<String> tenantIds,
                                          Set<String> volatileFields,String structuralSignature,String semanticSignature) {
    public ResponseSemanticFingerprint {contentType=contentType==null?"":contentType;if(responseClass==null)responseClass=SemanticResponseClass.UNKNOWN;fields=Set.copyOf(fields==null?Set.of():fields);resourceIds=Set.copyOf(resourceIds==null?Set.of():resourceIds);ownerIds=Set.copyOf(ownerIds==null?Set.of():ownerIds);tenantIds=Set.copyOf(tenantIds==null?Set.of():tenantIds);volatileFields=Set.copyOf(volatileFields==null?Set.of():volatileFields);structuralSignature=structuralSignature==null?"":structuralSignature;semanticSignature=semanticSignature==null?"":semanticSignature;}
}
