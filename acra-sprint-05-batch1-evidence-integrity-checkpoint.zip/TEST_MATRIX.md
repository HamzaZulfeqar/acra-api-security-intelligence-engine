# Test Matrix

Current S5 defensive verification: `docs/testing/artifacts/verification-s5-defensive.json` and `docs/sprints/sprint-05-final-software-closure.md`. The S5 suite is partial; missing modules have no executable evidence. Historical records below are retained.

Canonical test matrix: [`docs/testing/TEST_MATRIX.md`](docs/testing/TEST_MATRIX.md).

The canonical matrix includes the newly executed `S4-PHASE3` product profiles, selection/user modes, queue, local consent, backoff/error, resolver, coverage/efficiency, research-software and active UI source/binding results, plus the retained verified graph and ACRA-Lab milestones.


S5-03 function-level authorization reasoning foundation added.

## S5 Batch 1 evidence integrity — newly executed status

`Sprint5EvidenceIntegrityTestSuite` was added for evidence-store validation, ownership, project scope, replay separation, immutability, correlation fail-closed behavior, and serialization leakage. The requested `javac --release 21 -Xlint:all -Werror` compile and test run is **BLOCKED / NOT EXECUTED**: the only discovered compiler is OpenJDK 17.0.8, Java 21 release support is unavailable, `javac` is not on PATH, and Maven is unavailable. No new pass count is claimed.

Checkpoint packaging was newly verified separately: 604 files, no unsafe paths, no build/cache entries, clean extraction equality, and a matching external SHA-256 sidecar.
